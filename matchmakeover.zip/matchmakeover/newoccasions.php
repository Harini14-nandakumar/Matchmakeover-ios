<?php
// Database configuration
$host = "localhost";
$dbname = "match_makeover";
$username = "root";
$password = "";

// Connect to the database
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(["status" => "error", "message" => "Database connection failed: " . $e->getMessage()]));
}

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the occasion name from the request body
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($data['occasion_name']) && !empty(trim($data['occasion_name']))) {
        $occasionName = trim($data['occasion_name']);

        try {
            // Check if the occasion already exists
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM occasions WHERE name = :name");
            $stmt->execute(['name' => $occasionName]);
            $count = $stmt->fetchColumn();

            if ($count > 0) {
                echo json_encode(["status" => "error", "message" => "Occasion already exists"]);
                exit;
            }

            // Insert the new occasion
            $stmt = $pdo->prepare("INSERT INTO occasions (name) VALUES (:name)");
            $stmt->execute(['name' => $occasionName]);

            echo json_encode(["status" => "success", "message" => "Occasion added successfully"]);
        } catch (PDOException $e) {
            echo json_encode(["status" => "error", "message" => "Failed to add occasion: " . $e->getMessage()]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid occasion name"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}
?>
