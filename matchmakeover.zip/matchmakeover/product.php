<?php
header("Content-Type: application/json");

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "match_makeover";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the product data from POST request
$genderid = isset($_POST['genderid']) ? $_POST['genderid'] : null;
$categoriesid = isset($_POST['categoriesid']) ? $_POST['categoriesid'] : null;
$occasionsid = isset($_POST['occasionsid']) ? $_POST['occasionsid'] : null;
$coloursid = isset($_POST['coloursid']) ? $_POST['coloursid'] : null;

if (empty($genderid) || empty($categoriesid) || empty($occasionsid) || empty($coloursid)) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}

// Define the upload directory
$uploadDirectory = "uploads/";

// Check if the upload directory exists, if not, create it
if (!is_dir($uploadDirectory)) {
    if (!mkdir($uploadDirectory, 0777, true)) {
        echo json_encode(["status" => "error", "message" => "Failed to create upload directory"]);
        exit();
    }
}

// Handle multiple image uploads
$imagePaths = [];

foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
    $imageName = basename($_FILES['images']['name'][$key]);
    $imagePath = $uploadDirectory . $imageName;

    // Check if file is an image
    if (getimagesize($tmp_name)) {
        if (move_uploaded_file($tmp_name, $imagePath)) {
            $imagePaths[] = $imagePath;
        } else {
            echo json_encode(["status" => "error", "message" => "Error uploading image: $imageName"]);
            exit();
        }
    } else {
        echo json_encode(["status" => "error", "message" => "File is not an image: $imageName"]);
        exit();
    }
}

// Encode the image paths array as a JSON string
$imagePathsJson = json_encode($imagePaths);

// Insert the product details and images into the database
$stmt = $conn->prepare("INSERT INTO product (genderid, categoriesid, occasionsid, coloursid, images) 
                        VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("iiiss", $genderid, $categoriesid, $occasionsid, $coloursid, $imagePathsJson);

// Execute the query
if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Product added successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Error adding product"]);
}

$stmt->close();
$conn->close();
?>
